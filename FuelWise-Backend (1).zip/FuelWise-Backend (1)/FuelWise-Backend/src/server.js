require('dotenv').config();
const express=require('express'),cors=require('cors'),helmet=require('helmet'),rateLimit=require('express-rate-limit'),path=require('path');
const app=express();
if(!process.env.JWT_SECRET||process.env.JWT_SECRET.length<32){console.error('JWT_SECRET must be set to a random string with at least 32 characters.');process.exit(1)}
app.use(helmet({contentSecurityPolicy:false}));app.use(cors({origin:process.env.CLIENT_ORIGIN||'http://localhost:3000'}));app.use(express.json({limit:'1mb'}));app.use('/api/auth/login',rateLimit({windowMs:15*60*1000,max:10,standardHeaders:true,legacyHeaders:false}));
app.get('/api/health',(req,res)=>res.json({status:'ok',service:'FuelWise API',time:new Date().toISOString()}));
app.use('/api/auth',require('./routes/auth'));
app.use('/api/vehicles',require('./routes/vehicles'));
app.use('/api/transactions',require('./routes/transactions'));
app.use('/api/analytics',require('./routes/analytics'));
app.use('/api/scenarios',require('./routes/scenarios'));
app.use('/api/users',require('./routes/users'));
app.use('/api/reports',require('./routes/reports'));
app.use(express.static(path.join(__dirname,'../public')));
app.use((req,res)=>res.status(404).json({error:'Endpoint not found.'}));
app.use((err,req,res,next)=>{console.error(err);if(err.code==='ER_DUP_ENTRY')return res.status(409).json({error:'A record with this value already exists.'});if(err.code==='ER_NO_REFERENCED_ROW_2')return res.status(400).json({error:'The selected related record does not exist.'});res.status(500).json({error:process.env.NODE_ENV==='production'?'Internal server error.':err.message});});
const port=Number(process.env.PORT||3000);app.listen(port,()=>console.log(`FuelWise server running at http://localhost:${port}`));
