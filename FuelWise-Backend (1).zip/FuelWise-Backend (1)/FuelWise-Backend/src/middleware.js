const jwt = require('jsonwebtoken');
exports.auth = (req,res,next)=>{const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):null;if(!token)return res.status(401).json({error:'Authentication required.'});try{req.user=jwt.verify(token,process.env.JWT_SECRET);next();}catch(e){return res.status(401).json({error:'Session expired or invalid token.'});}};
exports.allow = (...roles)=>(req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:'Your account role does not have permission for this action.'});
exports.asyncRoute = fn => (req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
