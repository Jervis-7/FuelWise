CREATE DATABASE IF NOT EXISTS fuelwise CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fuelwise;
CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY, full_name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL, role ENUM('Admin','Manager','Staff') NOT NULL DEFAULT 'Staff',
 is_active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS vehicles (
 id INT AUTO_INCREMENT PRIMARY KEY, plate_no VARCHAR(30) NOT NULL UNIQUE, vehicle_name VARCHAR(100) NOT NULL,
 vehicle_type ENUM('Truck','Van','Car','Motorcycle','Other') NOT NULL, fuel_type ENUM('Diesel','Gasoline') NOT NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1, created_by INT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS fuel_transactions (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, vehicle_id INT NOT NULL, transaction_date DATE NOT NULL,
 fuel_type ENUM('Diesel','Gasoline') NOT NULL, liters DECIMAL(12,2) NOT NULL, price_per_liter DECIMAL(12,2) NOT NULL,
 total_cost DECIMAL(14,2) GENERATED ALWAYS AS (ROUND(liters * price_per_liter,2)) STORED,
 odometer_km DECIMAL(14,2) NULL, reference_no VARCHAR(100) NULL, notes TEXT NULL, recorded_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_tx_date(transaction_date), INDEX idx_tx_vehicle(vehicle_id),
 FOREIGN KEY(vehicle_id) REFERENCES vehicles(id), FOREIGN KEY(recorded_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS saved_scenarios (
 id INT AUTO_INCREMENT PRIMARY KEY, scenario_name VARCHAR(120) NOT NULL, current_price DECIMAL(12,2) NOT NULL,
 scenario_price DECIMAL(12,2) NOT NULL, monthly_liters DECIMAL(12,2) NOT NULL, created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS report_exports (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, report_name VARCHAR(150) NOT NULL, period_label VARCHAR(100) NOT NULL,
 file_format ENUM('CSV','PDF','Excel') NOT NULL DEFAULT 'CSV', generated_by INT NULL,
 generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(generated_by) REFERENCES users(id) ON DELETE SET NULL
);
