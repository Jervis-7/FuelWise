# FuelWise Backend (Node.js + Express + MySQL)

This package contains the supplied FuelWise HTML interface in `public/index.html` and a REST API built for its modules. The API stores application records in MySQL, uses bcrypt password hashes and JWT authentication, and enforces Admin / Manager / Staff permissions.

## 1. Requirements
- Node.js 18 or newer
- XAMPP (MySQL) or another MySQL 8-compatible server
- VS Code (recommended)

## 2. Database setup
1. Start MySQL in XAMPP.
2. Open phpMyAdmin (`http://localhost/phpmyadmin`).
3. Import `database.sql`.

## 3. Configure and start
1. Open this folder in VS Code.
2. Copy `.env.example` and rename the copy to `.env`.
3. Set a private `JWT_SECRET` (at least 32 characters) and your MySQL settings.
4. In the terminal run:

```bash
npm install
npm run seed
npm start
```

5. Open `http://localhost:3000`.

## Demo account
- Admin: `admin@fuelwise.com`
- Password: `Fuelwise123!`

Change the demo password after first login in a production deployment. The seed command only creates the initial sample accounts and vehicles when the users table is empty.

## API overview
All endpoints except `GET /api/health` and `POST /api/auth/login` require:

`Authorization: Bearer YOUR_JWT_TOKEN`

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/login` | Public | Authenticate and receive JWT |
| GET | `/api/auth/me` | Signed in | Current user profile |
| POST | `/api/auth/change-password` | Signed in | Change password |
| GET, POST | `/api/vehicles` | Signed in / Admin+Manager | List and add vehicles |
| PUT | `/api/vehicles/:id` | Admin+Manager | Edit vehicle |
| DELETE | `/api/vehicles/:id` | Admin | Deactivate vehicle |
| GET, POST | `/api/transactions` | Signed in | List and record fuel transactions |
| DELETE | `/api/transactions/:id` | Admin+Manager | Delete a transaction |
| GET | `/api/analytics/summary` | Admin+Manager | Dashboard KPIs, monthly trend, top vehicles, recent entries |
| GET | `/api/analytics/forecast` | Admin+Manager | 3-month moving-average forecast |
| GET, POST, DELETE | `/api/scenarios` | Admin+Manager | Save and manage price scenarios |
| GET, POST, PUT | `/api/users` | Admin | Manage users and roles |
| GET | `/api/reports/fuel-expenses` | Admin+Manager | Filtered report data |
| GET, POST | `/api/reports/exports` | Admin+Manager | Export history |

## Example login request
```http
POST /api/auth/login
Content-Type: application/json

{"login":"admin@fuelwise.com","password":"Fuelwise123!"}
```

## Important integration note
The supplied `FuelWise.html` is a self-contained browser prototype. Its current JavaScript uses browser `localStorage` and local demo data. This package preserves that original interface and provides the corresponding database-backed REST API separately. To make every screen read/write MySQL instead of browser storage, its existing `persist()`, login, and form handlers must be connected to these API endpoints. Do not treat the prototype's localStorage records as server-saved records until that front-end integration is completed.

## Security notes
- Passwords are stored as bcrypt hashes.
- API routes use signed JWTs and role checks.
- Login is rate-limited.
- SQL statements use parameterized queries.
- Use HTTPS and a strong private JWT secret before deployment.
